#!/usr/bin/env bash

HOME=$(pwd)

functions=(
           "crawler/trigger_glue_crawler" \
           "crawler/get_glue_crawler_state" \
           "redshift/consumption" \
           "meter_forecast/upload_result"  \
           "meter_forecast/split_batch"  \
           "meter_forecast/prepare_training"  \
           "meter_forecast/prepare_batch"  \
           "meter_forecast" \
           "get_anomaly"  \
           "meter_forecast/batch_anomaly_detection" \
           "state_topic_subscription" \
           "meter_forecast/load_pipeline_parameter" \
           "outage_info" \
           "meter_forecast/check_initial_pipeline_run")

for lambda_folder in ${functions[*]};
do
   function_name=${lambda_folder////_}
   echo $function_name
   (cd $lambda_folder; zip -9qr "$HOME/packages/${function_name}.zip" .;cd $HOME)
done